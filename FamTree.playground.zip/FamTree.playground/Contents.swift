import UIKit

enum Sex: String {
    case male
    case female
    case undefined
}

enum Occupation: String {
    case doctor
    case programmer
    case janitor
    case singer
    case actor
    case teacher
    case policeman
    case fireman
    case gamer
    case movieMaker
    case farmer
    case builder
    case student
    case astronaut
    case architect
    case director
    case engineer
    case carpenter
    case cashier
    case waiter
    case driver
    case mechanic
    case priest
    case president
    case mayor
}

class Person {
    
    let firstName: String
    let lastName: String
    let age: Int
    let sex: Sex
    let occupation: Occupation
    let numberOfChildren: Int?
    
    var fullName: String {
        return firstName + " " + lastName
    }
    
    init(firstName: String, lastName: String, age: Int, sex: Sex, occupation: Occupation, numberOfChildren: Int? = nil) {
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
        self.sex = sex
        self.occupation = occupation
        self.numberOfChildren = numberOfChildren
    }
    
    func description() -> String {
        if numberOfChildren == nil {
            return "\(fullName) is \(age) years old, is a \(sex.rawValue) and works as a \(occupation.rawValue)."
        }
        return "\(fullName) is \(age) years old, is a \(sex.rawValue), works as a \(occupation.rawValue) and has \(numberOfChildren!) child/children."
    }
}

var george = Person(firstName: "George", lastName: "Predan", age: 17, sex: .male, occupation: .student)
var valentina = Person(firstName: "Valentina", lastName: "Popa", age: 50, sex: .female, occupation: .doctor, numberOfChildren: 3)
var alexandru = Person(firstName: "Alexandru", lastName: "Oancea", age: 34, sex: .male, occupation: .teacher, numberOfChildren: 1)
var anna = Person(firstName: "Anna", lastName: "Smith", age: 22, sex: .female, occupation: .waiter)
var john = Person(firstName: "John", lastName: "Deacon", age: 70, sex: .male, occupation: .singer, numberOfChildren: 4)
print(george.description())
print(alexandru.description())
print(anna.description())
print(john.description())
print(valentina.description())
